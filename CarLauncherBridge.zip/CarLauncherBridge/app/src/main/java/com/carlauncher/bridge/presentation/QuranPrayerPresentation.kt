package com.carlauncher.bridge.presentation

import android.app.Presentation
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Display
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

class QuranPrayerPresentation(
    outerContext: Context,
    display: Display,
    private val onBackHome: () -> Unit
) : Presentation(outerContext, display) {

    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(context).build()

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1E1B4B"))
            setPadding(36, 28, 36, 28)
        }

        val prayerInfo = TextView(context).apply {
            text = "مواقيت الصلاة (نموذج مبدئي): الفجر 05:15 | الظهر 12:30 | العصر 15:45 | المغرب 18:10 | العشاء 19:30"
            textSize = 20f
            setTextColor(Color.parseColor("#E0E7FF"))
            setPadding(0, 16, 0, 24)
        }

        val playSurahBtn = Button(context).apply {
            text = "تشغيل سورة الفاتحة - مشاري العفاسي"
            setOnClickListener {
                player?.setMediaItem(MediaItem.fromUri("https://server8.mp3quran.net/afs/001.mp3"))
                player?.prepare()
                player?.play()
            }
        }

        val backBtn = Button(context).apply {
            text = "العودة للرئيسية"
            setOnClickListener { onBackHome() }
        }

        root.addView(backBtn)
        root.addView(prayerInfo)
        root.addView(playSurahBtn)
        setContentView(root)
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }
}
