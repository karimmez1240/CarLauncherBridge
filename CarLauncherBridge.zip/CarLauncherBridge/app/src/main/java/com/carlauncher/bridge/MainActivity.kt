package com.carlauncher.bridge

import android.content.Intent
import android.hardware.usb.UsbAccessory
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.carlauncher.bridge.service.CarBridgeService

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleUsbIntent(intent)

        setContent {
            val status by CarBridgeService.statusText.collectAsState()
            var wifiIp by remember { mutableStateOf("192.168.49.1") }

            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text("CarLauncher Bridge", style = MaterialTheme.typography.headlineMedium)
                        Text("الحالة: $status", style = MaterialTheme.typography.bodyLarge)

                        OutlinedTextField(
                            value = wifiIp,
                            onValueChange = { wifiIp = it },
                            label = { Text("عنوان IP لشاشة السيارة (Wi-Fi Direct)") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = {
                                val svc = Intent(this@MainActivity, CarBridgeService::class.java).apply {
                                    action = CarBridgeService.ACTION_START_WIFI
                                    putExtra(CarBridgeService.EXTRA_WIFI_HOST, wifiIp)
                                }
                                startForegroundService(svc)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("تشغيل البث اللاسلكي (Wi-Fi)")
                        }

                        OutlinedButton(
                            onClick = {
                                val svc = Intent(this@MainActivity, CarBridgeService::class.java).apply {
                                    action = CarBridgeService.ACTION_STOP
                                }
                                startService(svc)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("إيقاف البث")
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleUsbIntent(intent)
    }

    private fun handleUsbIntent(intent: Intent?) {
        if (intent?.action == UsbManager.ACTION_USB_ACCESSORY_ATTACHED) {
            val accessory = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(UsbManager.EXTRA_ACCESSORY, UsbAccessory::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(UsbManager.EXTRA_ACCESSORY)
            }
            if (accessory != null) {
                val svc = Intent(this, CarBridgeService::class.java).apply {
                    action = CarBridgeService.ACTION_START_USB
                    putExtra(UsbManager.EXTRA_ACCESSORY, accessory)
                }
                startForegroundService(svc)
            }
        }
    }
}
