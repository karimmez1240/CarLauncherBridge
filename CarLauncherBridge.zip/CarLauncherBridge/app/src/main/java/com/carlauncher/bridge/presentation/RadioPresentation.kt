package com.carlauncher.bridge.presentation

import android.app.Presentation
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Display
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

class RadioPresentation(
    outerContext: Context,
    display: Display,
    private val onBackHome: () -> Unit
) : Presentation(outerContext, display) {

    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(context).build()

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F172A"))
            setPadding(36, 28, 36, 28)
        }

        val status = TextView(context).apply {
            text = "اختر محطة راديو للتشغيل"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(0, 16, 0, 24)
        }

        fun stationBtn(name: String, streamUrl: String) = Button(context).apply {
            text = name
            textSize = 18f
            setOnClickListener {
                status.text = "جارٍ تشغيل: $name"
                player?.setMediaItem(MediaItem.fromUri(streamUrl))
                player?.prepare()
                player?.play()
            }
        }

        val backBtn = Button(context).apply {
            text = "العودة للرئيسية"
            setOnClickListener { onBackHome() }
        }

        val stopBtn = Button(context).apply {
            text = "إيقاف التشغيل"
            setOnClickListener {
                player?.pause()
                status.text = "متوقف"
            }
        }

        root.addView(backBtn)
        root.addView(status)
        root.addView(stationBtn("إذاعة القرآن الكريم", "https://stream.radiojar.com/8s5u5tpdtwzuv"))
        root.addView(stationBtn("راديو الأخبار والموسيقى", "https://stream.live.vc.bbcmedia.co.uk/bbc_arabic_radio"))
        root.addView(stopBtn)
        setContentView(root)
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }
}
