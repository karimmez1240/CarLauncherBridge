package com.carlauncher.bridge.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.hardware.usb.UsbAccessory
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.IBinder
import com.carlauncher.bridge.protocol.CarScreenConfig
import com.carlauncher.bridge.protocol.CarTransport
import com.carlauncher.bridge.protocol.CarbitLinkProtocol
import com.carlauncher.bridge.protocol.UsbTransport
import com.carlauncher.bridge.protocol.WifiDirectTransport
import com.carlauncher.bridge.video.CarDisplayManager
import com.carlauncher.bridge.video.CarVideoEncoder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class CarBridgeService : Service() {

    companion object {
        const val ACTION_START_USB = "com.carlauncher.bridge.START_USB"
        const val ACTION_START_WIFI = "com.carlauncher.bridge.START_WIFI"
        const val ACTION_STOP = "com.carlauncher.bridge.STOP"
        const val EXTRA_WIFI_HOST = "wifi_host"
        private const val CHANNEL_ID = "car_bridge_channel"

        private val _statusText = MutableStateFlow("غير متصل")
        val statusText: StateFlow<String> = _statusText
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val config = CarScreenConfig()
    private var transport: CarTransport? = null
    private var encoder: CarVideoEncoder? = null
    private var displayManager: CarDisplayManager? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(1, buildNotification("جاهز للاتصال بشاشة السيارة"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_USB -> {
                val accessory = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(UsbManager.EXTRA_ACCESSORY, UsbAccessory::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(UsbManager.EXTRA_ACCESSORY)
                }
                if (accessory != null) {
                    val usbManager = getSystemService(USB_SERVICE) as UsbManager
                    startBridge(UsbTransport(usbManager, accessory), "متصل عبر USB")
                }
            }
            ACTION_START_WIFI -> {
                val host = intent.getStringExtra(EXTRA_WIFI_HOST) ?: "192.168.49.1"
                startBridge(WifiDirectTransport(host), "متصل لاسلكياً ($host)")
            }
            ACTION_STOP -> {
                stopBridge()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startBridge(newTransport: CarTransport, label: String) {
        stopBridge()
        transport = newTransport
        _statusText.value = "جارٍ الاتصال..."

        serviceScope.launch {
            val ok = newTransport.connect()
            if (!ok) {
                _statusText.value = "فشل الاتصال بشاشة السيارة"
                return@launch
            }
            newTransport.sendPacket(CarbitLinkProtocol.buildHandshakePacket())
            _statusText.value = label

            val enc = CarVideoEncoder(config) { h264 ->
                serviceScope.launch {
                    runCatching {
                        newTransport.sendPacket(CarbitLinkProtocol.buildVideoPacket(h264))
                    }
                }
            }
            encoder = enc
            val surface = enc.start()

            val dm = CarDisplayManager(this@CarBridgeService, config)
            displayManager = dm
            dm.start(surface)
            enc.requestKeyFrame()

            newTransport.incomingPackets.collect { packet ->
                CarbitLinkProtocol.parseTouchPacket(packet, config.width, config.height)?.let { touch ->
                    dm.dispatchTouch(touch)
                }
            }
        }
    }

    private fun stopBridge() {
        displayManager?.stop()
        displayManager = null
        encoder?.stop()
        encoder = null
        transport?.close()
        transport = null
        _statusText.value = "غير متصل"
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "CarLauncher Bridge", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(text: String): Notification {
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("CarLauncher Bridge")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
    }

    override fun onDestroy() {
        stopBridge()
        serviceScope.cancel()
        super.onDestroy()
    }
}
