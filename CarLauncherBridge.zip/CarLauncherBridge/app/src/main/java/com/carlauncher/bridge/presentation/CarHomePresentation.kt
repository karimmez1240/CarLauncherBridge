package com.carlauncher.bridge.presentation

import android.annotation.SuppressLint
import android.app.Presentation
import android.content.Context
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.carlauncher.bridge.service.CarMediaListenerService
import com.carlauncher.bridge.video.LauncherScreenMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CarHomePresentation(
    outerContext: Context,
    display: Display,
    private val onNavigate: (LauncherScreenMode) -> Unit
) : Presentation(outerContext, display) {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var clockText: TextView
    private lateinit var speedText: TextView
    private lateinit var mediaText: TextView
    private var locationManager: LocationManager? = null

    private val clockTicker = object : Runnable {
        override fun run() {
            clockText.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            mediaText.text = CarMediaListenerService.currentTrackSummary
            handler.postDelayed(this, 1000)
        }
    }

    private val speedListener = LocationListener { location: Location ->
        val kmh = (location.speed * 3.6f).toInt()
        speedText.text = "$kmh km/h"
    }

    @SuppressLint("MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F172A"))
            setPadding(36, 28, 36, 28)
        }

        val topBar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        clockText = TextView(context).apply {
            textSize = 36f
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        speedText = TextView(context).apply {
            text = "0 km/h"
            textSize = 28f
            setTextColor(Color.parseColor("#38BDF8"))
        }

        topBar.addView(clockText)
        topBar.addView(speedText)

        mediaText = TextView(context).apply {
            text = "لا توجد وسائط قيد التشغيل"
            textSize = 18f
            setTextColor(Color.parseColor("#CBD5E1"))
            setPadding(0, 16, 0, 24)
        }

        val tilesRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }

        fun makeTile(title: String, colorHex: String, mode: LauncherScreenMode): Button {
            return Button(context).apply {
                text = title
                textSize = 20f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor(colorHex))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply {
                    setMargins(10, 10, 10, 10)
                }
                setOnClickListener { onNavigate(mode) }
            }
        }

        tilesRow.addView(makeTile("الخرائط والويب", "#1D4ED8", LauncherScreenMode.WEB_MAPS))
        tilesRow.addView(makeTile("الراديو", "#0F766E", LauncherScreenMode.RADIO))
        tilesRow.addView(makeTile("القرآن والصلاة", "#7E22CE", LauncherScreenMode.QURAN_PRAYER))

        root.addView(topBar)
        root.addView(mediaText)
        root.addView(tilesRow)
        setContentView(root)

        handler.post(clockTicker)
        locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        runCatching {
            locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 1f, speedListener)
        }
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(clockTicker)
        runCatching { locationManager?.removeUpdates(speedListener) }
    }
}
