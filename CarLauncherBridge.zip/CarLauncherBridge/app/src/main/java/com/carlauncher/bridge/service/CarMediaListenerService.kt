package com.carlauncher.bridge.service

import android.media.MediaMetadata
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class CarMediaListenerService : NotificationListenerService() {
    companion object {
        @Volatile
        var currentTrackSummary: String = "لا توجد وسائط قيد التشغيل"
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val extras = sbn?.notification?.extras ?: return
        val title = extras.getCharSequence("android.title")?.toString() ?: return
        val text = extras.getCharSequence("android.text")?.toString().orEmpty()
        if (sbn.notification.category == "transport") {
            currentTrackSummary = if (text.isNotBlank()) "$title — $text" else title
        }
    }
}
