package com.carlauncher.bridge.video

import android.app.Presentation
import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.Surface
import com.carlauncher.bridge.presentation.CarHomePresentation
import com.carlauncher.bridge.presentation.QuranPrayerPresentation
import com.carlauncher.bridge.presentation.RadioPresentation
import com.carlauncher.bridge.presentation.WebMapsPresentation
import com.carlauncher.bridge.protocol.CarScreenConfig
import com.carlauncher.bridge.protocol.CarTouchEvent

enum class LauncherScreenMode {
    HOME, WEB_MAPS, RADIO, QURAN_PRAYER
}

class CarDisplayManager(
    private val context: Context,
    private val config: CarScreenConfig
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var virtualDisplay: VirtualDisplay? = null
    private var activePresentation: Presentation? = null
    private var downTimeMs: Long = 0L

    fun start(surface: Surface) {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        virtualDisplay = dm.createVirtualDisplay(
            "CarLauncherVirtualDisplay",
            config.width,
            config.height,
            160,
            surface,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION or
                DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
        )
        switchScreen(LauncherScreenMode.HOME)
    }

    fun switchScreen(mode: LauncherScreenMode) {
        mainHandler.post {
            val display = virtualDisplay?.display ?: return@post
            runCatching { activePresentation?.dismiss() }
            activePresentation = when (mode) {
                LauncherScreenMode.HOME -> CarHomePresentation(context, display, ::switchScreen)
                LauncherScreenMode.WEB_MAPS -> WebMapsPresentation(context, display) { switchScreen(LauncherScreenMode.HOME) }
                LauncherScreenMode.RADIO -> RadioPresentation(context, display) { switchScreen(LauncherScreenMode.HOME) }
                LauncherScreenMode.QURAN_PRAYER -> QuranPrayerPresentation(context, display) { switchScreen(LauncherScreenMode.HOME) }
            }.also {
                runCatching { it.show() }
            }
        }
    }

    fun dispatchTouch(touch: CarTouchEvent) {
        mainHandler.post {
            val now = SystemClock.uptimeMillis()
            if (touch.action == MotionEvent.ACTION_DOWN) {
                downTimeMs = now
            }
            val event = MotionEvent.obtain(downTimeMs, now, touch.action, touch.x, touch.y, 0)
            activePresentation?.window?.decorView?.dispatchTouchEvent(event)
            event.recycle()
        }
    }

    fun stop() {
        mainHandler.post {
            runCatching { activePresentation?.dismiss() }
            activePresentation = null
        }
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
    }
}
