package com.carlauncher.bridge.presentation

import android.annotation.SuppressLint
import android.app.Presentation
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Display
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout

class WebMapsPresentation(
    outerContext: Context,
    display: Display,
    private val onBackHome: () -> Unit
) : Presentation(outerContext, display) {

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }

        val webView = WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            loadUrl("https://www.openstreetmap.org")
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }

        val navBar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#1E293B"))
        }

        fun navBtn(label: String, onClick: () -> Unit) = Button(context).apply {
            text = label
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { onClick() }
        }

        navBar.addView(navBtn("الرئيسية", onBackHome))
        navBar.addView(navBtn("الخرائط") { webView.loadUrl("https://www.openstreetmap.org") })
        navBar.addView(navBtn("تحديث") { webView.reload() })

        root.addView(navBar)
        root.addView(webView)
        setContentView(root)
    }
}
