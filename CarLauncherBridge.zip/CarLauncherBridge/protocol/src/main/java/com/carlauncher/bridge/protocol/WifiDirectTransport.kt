package com.carlauncher.bridge.protocol

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket

class WifiDirectTransport(
    private val host: String,
    private val port: Int = 10922
) : CarTransport {

    private var socket: Socket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    override var isConnected: Boolean = false
        private set

    override suspend fun connect(): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val s = Socket()
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(host, port), 5000)
            socket = s
            input = s.getInputStream()
            output = s.getOutputStream()
            isConnected = true
            true
        }.getOrDefault(false)
    }

    override val incomingPackets: Flow<ByteArray> = flow {
        val stream = input ?: return@flow
        val buffer = ByteArray(16 * 1024)
        while (isConnected) {
            val read = stream.read(buffer)
            if (read <= 0) break
            emit(buffer.copyOf(read))
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun sendPacket(packet: ByteArray) = withContext(Dispatchers.IO) {
        output?.write(packet)
        output?.flush()
        Unit
    }

    override fun close() {
        isConnected = false
        runCatching { input?.close() }
        runCatching { output?.close() }
        runCatching { socket?.close() }
    }
}
