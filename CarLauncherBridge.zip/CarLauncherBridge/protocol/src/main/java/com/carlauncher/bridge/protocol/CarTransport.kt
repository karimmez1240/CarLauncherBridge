package com.carlauncher.bridge.protocol

import kotlinx.coroutines.flow.Flow

data class CarScreenConfig(
    val width: Int = 1024,
    val height: Int = 536,
    val fps: Int = 30,
    val bitRate: Int = 4_194_304
)

data class CarTouchEvent(
    val action: Int,
    val x: Float,
    val y: Float,
    val pointerId: Int = 0
)

interface CarTransport {
    val isConnected: Boolean
    val incomingPackets: Flow<ByteArray>
    suspend fun connect(): Boolean
    suspend fun sendPacket(packet: ByteArray)
    fun close()
}
