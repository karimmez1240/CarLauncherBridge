package com.carlauncher.bridge.protocol

import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * تغليف وفك تغليف حزم بروتوكول CarbitLink (الفيديو H.264، اللمس، والمصافحة).
 */
object CarbitLinkProtocol {
    const val MAGIC_HEADER: Short = 0x1000
    const val TYPE_HANDSHAKE: Short = 0x0001
    const val TYPE_VIDEO_H264: Short = 0x0002
    const val TYPE_TOUCH: Short = 0x0003
    const val TYPE_HEARTBEAT: Short = 0x0004

    fun buildHandshakePacket(deviceName: String = "CarLauncherBridge"): ByteArray {
        val json = JSONObject().apply {
            put("appName", deviceName)
            put("supportScreenMirroring", true)
            put("supportScreenTouch", true)
            put("protocolVersion", "1.0")
        }.toString().toByteArray(Charsets.UTF_8)

        return wrapFrame(TYPE_HANDSHAKE, json)
    }

    fun buildVideoPacket(h264Data: ByteArray): ByteArray {
        return wrapFrame(TYPE_VIDEO_H264, h264Data)
    }

    fun buildHeartbeatPacket(): ByteArray {
        return wrapFrame(TYPE_HEARTBEAT, ByteArray(0))
    }

    fun wrapFrame(type: Short, payload: ByteArray): ByteArray {
        val buffer = ByteBuffer.allocate(8 + payload.size).order(ByteOrder.LITTLE_ENDIAN)
        buffer.putShort(MAGIC_HEADER)
        buffer.putShort(type)
        buffer.putInt(payload.size)
        buffer.put(payload)
        return buffer.array()
    }

    fun parseTouchPacket(packet: ByteArray, screenWidth: Int, screenHeight: Int): CarTouchEvent? {
        if (packet.size < 16) return null
        val buffer = ByteBuffer.wrap(packet).order(ByteOrder.LITTLE_ENDIAN)
        val magic = buffer.short
        val type = buffer.short
        val length = buffer.int
        if (magic != MAGIC_HEADER || type != TYPE_TOUCH || length < 12 || packet.size < 8 + length) {
            return null
        }
        val action = buffer.int
        val normX = buffer.float.coerceIn(0f, 1f)
        val normY = buffer.float.coerceIn(0f, 1f)
        return CarTouchEvent(
            action = action,
            x = normX * screenWidth,
            y = normY * screenHeight
        )
    }
}
