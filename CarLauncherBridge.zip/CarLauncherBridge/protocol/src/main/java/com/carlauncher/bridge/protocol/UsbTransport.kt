package com.carlauncher.bridge.protocol

import android.hardware.usb.UsbAccessory
import android.hardware.usb.UsbManager
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.FileInputStream
import java.io.FileOutputStream

class UsbTransport(
    private val usbManager: UsbManager,
    private val accessory: UsbAccessory
) : CarTransport {

    private var pfd: ParcelFileDescriptor? = null
    private var input: FileInputStream? = null
    private var output: FileOutputStream? = null

    override var isConnected: Boolean = false
        private set

    override suspend fun connect(): Boolean = withContext(Dispatchers.IO) {
        val descriptor = usbManager.openAccessory(accessory) ?: return@withContext false
        pfd = descriptor
        input = FileInputStream(descriptor.fileDescriptor)
        output = FileOutputStream(descriptor.fileDescriptor)
        isConnected = true
        true
    }

    override val incomingPackets: Flow<ByteArray> = flow {
        val stream = input ?: return@flow
        val buffer = ByteArray(16 * 1024)
        while (isConnected) {
            val read = stream.read(buffer)
            if (read <= 0) break
            emit(buffer.copyOf(read))
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun sendPacket(packet: ByteArray) = withContext(Dispatchers.IO) {
        output?.write(packet)
        output?.flush()
        Unit
    }

    override fun close() {
        isConnected = false
        runCatching { input?.close() }
        runCatching { output?.close() }
        runCatching { pfd?.close() }
    }
}
