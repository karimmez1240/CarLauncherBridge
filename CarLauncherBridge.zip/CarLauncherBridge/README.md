# CarLauncherBridge (نواة لانشر سيارة لـ CarbitLink)

مشروع Android Studio مبني من الصفر بلغة **Kotlin** لعرض واجهة لانشر سيارة مخصصة على شاشات السيارات الداعمة لـ **CarbitLink / EasyConnection** عبر **USB** أو **Wi-Fi Direct**، بدون الحاجة إلى Android Auto أو Root أو خدمات Accessibility.

## المكونات الرئيسية
- **طبقة الاتصال (`:protocol`)**: واجهات `CarTransport`، الاتصال السلكي عبر USB Accessory (`UsbTransport`)، والاتصال اللاسلكي عبر Wi-Fi Direct (`WifiDirectTransport`)، وتنسيق حزم CarbitLink (`CarbitLinkProtocol`).
- **محرك الفيديو والشاشة الافتراضية (`video/`)**:
  - `CarVideoEncoder`: تشفير `H.264` (`video/avc`) عبر `MediaCodec` بدقة `1024x536` ومعدل `4.19 Mbps`.
  - `CarDisplayManager`: إدارة `VirtualDisplay` والتبديل الآمن بين شاشات `Presentation` دون حدوث `InvalidDisplayException`.
- **شاشات اللانشر (`presentation/`)**:
  - `CarHomePresentation`: الشاشة الرئيسية (ساعة رقمية، سرعة GPS، تحكم بالوسائط، وأزرار التنقل).
  - `WebMapsPresentation`: متصفح ويب وخرائط مدمج (`WebView`).
  - `RadioPresentation`: راديو أونلاين عبر `Media3 ExoPlayer`.
  - `QuranPrayerPresentation`: مواقيت الصلاة + مشغل سور القرآن الكريم.

## طريقة البناء
1. افتح المجلد `CarLauncherBridge` في **Android Studio** (JDK 17 + Android SDK 34).
2. انتظر مزامنة Gradle، ثم شغّل `Build -> Build APK(s)` أو نفّذ:
   ```bash
   ./gradlew assembleDebug
   ```
3. ملاحظة حول بروتوكول سيارتك: إذا احتاجت شاشة سيارتك لتهيئة مصافحة خاصة، يمكنك استبدال وحدة `:protocol` أو تحديث دالة `sendHandshake()` في `CarbitLinkProtocol.kt`.
